<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Статус IP</title>
  <style>
    body {
      background: linear-gradient(to right, #ffdee9, #b5fffc);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }
    h1 {
      color: #333;
      margin-bottom: 20px;
    }
    .status-box {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      text-align: center;
    }
    .status {
      font-size: 24px;
      font-weight: bold;
      margin-top: 10px;
    }
    .online {
      color: green;
    }
    .offline {
      color: red;
    }
    input {
      padding: 10px;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
      width: 250px;
      text-align: center;
    }
    button {
      padding: 10px 20px;
      font-size: 16px;
      border-radius: 8px;
      border: none;
      background-color: #007bff;
      color: white;
      cursor: pointer;
    }
    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <h1>Проверка доступности IP</h1>
  <div class="status-box">
    <input type="text" id="ip" placeholder="Введите IP или домен">
    <button onclick="checkStatus()">Проверить</button>
    <div class="status" id="status">Ожидание ввода...</div>
  </div>

  <script>
    async function checkStatus() {
      const ip = document.getElementById('ip').value.trim();
      const statusEl = document.getElementById('status');
      statusEl.textContent = "Проверка...";
      statusEl.className = "status";

      if (!ip) {
        statusEl.textContent = "Введите IP или домен";
        statusEl.className = "status offline";
        return;
      }

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3000);

        await fetch(`http://${77.239.99.97}`, { mode: 'no-cors', signal: controller.signal });
        clearTimeout(timeout);
        statusEl.textContent = "Доступен";
        statusEl.className = "status online";
      } catch (e) {
        statusEl.textContent = "Недоступен";
        statusEl.className = "status offline";
      }
    }
  </script>
</body>
</html>